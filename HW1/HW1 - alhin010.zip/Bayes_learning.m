% Yahya Alhinai
% CSCI 5521 - HW1

function [p1, p2, pc1, pc2] = Bayes_Learning(training_data, validation_data)
    
    Tdata = training_data(:, 1:end-1);
    Vdata = validation_data(:, 1:end-1);
        
    t1 = (training_data(:, end) == 1);
    t2 = (training_data(:, end) == 2);

    p1 = (sum( Tdata(t1,:) ==0) / size(Tdata(t1, :),1))'; 
    p2 = (sum( Tdata(t2,:) ==0) / size(Tdata(t2, :),1))'; % For class 2

    sigma = [0.00001, 0.0001, 0.001, 0.01, 0.1, 1, 2, 3, 4, 5];


    C1 = 1 - exp(-sigma);
    C2 = 1 - C1;
    
    output = zeros(size(sigma,2),1);
    
    fprintf('\nError Rate:\n');
    fprintf('P(C1|sigma) \t Error rate\n');
    fprintf('----------------------------\n');
    for i = 1:size(sigma,2)
        v1 = zeros(size(validation_data,1),1);
        v2 = zeros(size(validation_data,1),1);
        sigmaPrediction = zeros(size(validation_data,1),1);

        for j = 1:size(validation_data,1)
            v1(j) = C1(1,i) * prod((p1 .^ (1-Vdata(j,:)')) .* (1-p1) .^ (Vdata(j,:)'));
            v2(j) = C2(1,i) * prod(p2 .^ (1-Vdata(j,:)') .* (1-p2) .^ (Vdata(j,:)'));

            if v1(j) > v2(j)
                sigmaPrediction(j) = 1;
            else
                sigmaPrediction(j) = 2;
            end
            
        end
        
        output(i) = sum(validation_data(:, end) == sigmaPrediction);

        fprintf('%d \t %.2f%%\n', sigma(i), (1-(output(i))/size(Vdata,1))*100);
    end

    [value, index] = max(output);
    pc1 = C1(index);
    pc2 = C2(index);

    fprintf('\nBest performance:\n');
    fprintf('sigma \t Error rate\n');
    fprintf('----------------------------\n');

    fprintf('%d \t\t %.2f%%\n', sigma(index), (1-(value/size(Vdata,1)))*100);

end
