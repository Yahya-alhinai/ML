function [] = Bayes_Testing(test_data, p1, p2, pc1, pc2)

set = test_data(:,1:end-1);
v1 = zeros(size(test_data,1),1);
v2 = zeros(size(test_data,1),1);
count = zeros(size(test_data,1),1);

for i=1:size(test_data,1)
        v1(i) = pc1*prod(p1.^(1-set(i, :)') .* (1-p1).^(set(i,:)'));
        v2(i) = pc2*prod(p2.^(1-set(i, :)') .* (1-p2).^(set(i,:)'));
        
        if v1(i) > v2(i)
            count(i) = 1;
        else
            count(i) = 2;
        end
end

error = test_data(:,end) - count;

fprintf('\nError Rate Using Best Prior:\n');
fprintf('%.2f%%\n\n', (1-sum(error(:)==0)/size(error,1))*100);

end