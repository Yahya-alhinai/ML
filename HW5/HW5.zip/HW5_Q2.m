%Yahya Alhinai
%HW5


%% Randomness
rng(1); % For reproducibility
r = sqrt(rand(100,1)); % Radius
t = 2*pi*rand(100,1); % Angle
data1 = [r.*cos(t), r.*sin(t)]; % Points
r2 = sqrt(3*rand(100,1)+2); % Radius
t2 = 2*pi*rand(100,1); % Angle
data2 = [r2.*cos(t2), r2.*sin(t2)]; % points

data3 = [data1;data2];
theclass = ones(200,1);
theclass(1:100) = -1;
N = size(data3,1);



%% 2A
degree = 2;

[error,alpha] = KernPercGD(data3,theclass,degree);

fprintf('Error = %d\n',error);

[x1,x2] = meshgrid(min(data3(:,1)):0.01:max(data3(:,1)), min(data3(:,2)):0.01:max(data3(:,2)));
x = [x1(:),x2(:)];

M = size(data3,1);
N = size(x,1);
kernel = zeros(M,N);
for i = 1:M
    for j = 1:N 
        kernel(i,j) = (1 + (data3(i,:)*x(j,:)'))^degree;
    end
end

test_scores = zeros(size(theclass,1),1);
for sampl = 1:size(x)
    test_scores(sampl) = ((alpha.*theclass)'*kernel(:,sampl));
end


figure;
h(1:2) = gscatter(data3(:,1),data3(:,2),theclass,'rb','.');
hold on

contour(x1,x2,reshape(test_scores(:,1),size(x1)),[0 0],'k');
legend('-1','+1','Kernel Perceptron');
axis equal




%% 2B
Penalty = 0.1;

cl = fitcsvm(data3,theclass,'KernelFunction','polynomial','PolynomialOrder',degree,'BoxConstraint',Penalty,'ClassNames',[-1,1]);

[x1,x2] = meshgrid(min(data3(:,1)):0.01:max(data3(:,1)),min(data3(:,2)):0.01:max(data3(:,2)));
x = [x1(:),x2(:)];
[~,scores] = predict(cl,x);

% Plot the data and the decision boundary on the same figure before
hold on  
%Comment below to not plot support vectors
h(3) = plot(data3(cl.IsSupportVector,1),data3(cl.IsSupportVector,2),'ko');
contour(x1,x2,reshape(scores(:,2),size(x1)),[0 0],'m-');
legend('-1','+1','Kernel Perceptron Hyperplane','support vectors','SVM boundary');
axis equal
hold off




%% 2C
degree = 2;
train_49 = csvread('optdigits49_train.txt');
test_49 = csvread('optdigits49_test.txt');
train_79 = csvread('optdigits79_train.txt');
test_79 = csvread('optdigits79_test.txt');

%pre-processing of digits data
train_labels49 = train_49(:,65);
train_49 = train_49(:,1:64);
test_labels49 = test_49(:,65);
test_49 = test_49(:,1:64);

train_labels79 = train_79(:,65);
train_79 = train_79(:,1:64);
test_labels79 = test_79(:,65);
test_79 = test_79(:,1:64);

[train_error49,alpha49] = KernPercGD(train_49,train_labels49,degree);
fprintf('train_error49 Training error = %.3f\n',train_error49*100);

M = size(train_49,1);
N = size(test_49,1);
k_test49 = zeros(M,N);
for i = 1:M
    for j = 1:N 
        k_test49(i,j) = (1 + (train_49(i,:)*test_49(j,:)'))^degree;
    end
end


pred49 = zeros(size(test_labels49,1),1);
for sampl = 1:size(test_labels49,1) 
    pred49(sampl) = sign((alpha49.*train_labels49)'*k_test49(:,sampl));
end

acc49 = (pred49 ~= test_labels49);
test_err49 = (sum(acc49)/size(test_labels49,1))*100;
fprintf('test_labels49 test error = %.3f\n',test_err49*100);


[train_error79,alpha79] = KernPercGD(train_79,train_labels79,degree);
fprintf('train_error79 Training error = %.3f\n',train_error79*100);

M = size(train_79,1);
N = size(test_79,1);
k_test79 = zeros(M,N);
for i = 1:M
    for j = 1:N 
        k_test79(i,j) = (1 + (train_79(i,:)*test_79(j,:)'))^degree;
    end
end


pred79 = zeros(size(test_labels79,1),1);
for sampl = 1:size(test_labels79,1) 
    pred79(sampl) = sign((alpha79.*train_labels79)'*k_test79(:,sampl));
end

acc79 = (pred79 ~= test_labels79);
test_err79 = (sum(acc79)/size(test_labels79,1))*100
fprintf('test_labels79 test error = %.3f\n',test_err79*100);


