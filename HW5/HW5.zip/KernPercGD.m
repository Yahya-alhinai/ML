function [train_err,alpha] = KernPercGD(in_data,train_labels,degree)

N = size(in_data,1);
alpha = zeros(N,1);
theclass = train_labels;

kern = zeros(N,N);
for i = 1:N
    for j = 1:N 
        kern(i,j) = (1 + (in_data(i,:)*in_data(j,:)'))^degree;
    end
end

for epochs = 1:100
    for t = 1:N        
        condition = (((alpha.*theclass)'*kern(:,t)))*theclass(t);
        if condition <= 0
            alpha(t) = alpha(t) + 1;
        end
    end
end

pred_labels = zeros(size(theclass,1),1);
for sampl = 1:N 
    pred_labels(sampl) = sign((alpha.*theclass)'*kern(:,sampl));
end

acc = (pred_labels == theclass);
train_err = 1 - (sum(acc)/size(theclass,1));

end